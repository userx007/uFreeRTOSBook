# Verification and fixes

Checked against FreeRTOS-Kernel (V11.1.0+ headers) with gcc -fsyntax-only (C/C++ blocks), plus an identifier scan.
Rust blocks were not compiled (no toolchain available).

- 112_Common_Configuration_Errors.md: 'portYILD_FROM_ISR' -> 'portYIELD_FROM_ISR' (1x) — typo: macro does not exist
- 02_FreeRTOS_Architecture.md: 'vTaskIncrementTick' -> 'xTaskIncrementTick' (2x) — kernel function is xTaskIncrementTick
- 07_FreeRTOSConfig.h_Configuration.md: '// Stream buffers\n#define configUSE_STREAM_BUFFERS          ' -> '// Stream buffers (default 1; message buffers are built on s' (1x) — configUSE_MESSAGE_BUFFERS does not exist
- 98_Version_Migration_Guide.md: '#define configUSE_MESSAGE_BUFFERS               1\n' -> '' (1x) — configUSE_MESSAGE_BUFFERS does not exist
- 42_SMP_Symmetric_Multiprocessing_Support.md: 'configNUM_CORES' -> 'configNUMBER_OF_CORES' (3x) — official SMP macro name
- 42_SMP_Symmetric_Multiprocessing_Support.md: 'configUSE_MINIMAL_IDLE_HOOK' -> 'configUSE_PASSIVE_IDLE_HOOK' (1x) — official name in V11 kernel
- 07_FreeRTOSConfig.h_Configuration.md: vApplicationGet*TaskMemory stack-size param -> configSTACK_DEPTH_TYPE * (matches V11 task.h)
- 34_Dynamic_vs_Static_Allocation.md: vApplicationGet*TaskMemory stack-size param -> configSTACK_DEPTH_TYPE * (matches V11 task.h)
- 93_CMake_Build_Configuration.md: '### Basic CMakeLists.txt for FreeRTOS\n\n```c\n' -> '### Basic CMakeLists.txt for FreeRTOS\n\n```cmake\n' (1x) — wrong language tag
- 118_FreeRTOS_LTS_Releases.md: '\n// LTS version tracking macro\n#define configFREERTOS_LTS_VE' -> '' (1x) — macros are not part of FreeRTOS; removed
- 35_Thread_Local_Storage.md: '### Setting Deletion Callbacks (if enabled)\n' -> '### Setting Deletion Callbacks (if enabled)\n\n> **Note:** `vT' (1x) — API is ESP-IDF specific
- 31_Task_Parameters_and_Return_Values.md: '    vTaskSetThreadLocalStoragePointer(NULL, 0, pTaskData);\n ' -> '    vTaskSetThreadLocalStoragePointer(NULL, 0, pTaskData);\n ' (1x) — ESP-IDF-only API used in generic code
- 118_FreeRTOS_LTS_Releases.md: '## What Are LTS Releases?\n' -> '## Verified Release Facts\n\n- The FreeRTOS 202406 LTS release' (1x) — added verified LTS facts (chapter lacked concrete release data)
- README.md: fixed "Miscelaneous"; listed the two chapters that were missing from the index (QEMU and Renode testing, files 64_/65_).
- Not changed: chapter file numbering (64 and 65 each exist twice); the book (EPUB/DOCX) numbers chapters sequentially.
